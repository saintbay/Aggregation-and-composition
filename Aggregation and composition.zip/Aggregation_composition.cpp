﻿//#include <iostream>
//
//struct Node {
//    int data;
//    Node* next;
//};
//
//class Stack {
//private:
//    Node* top;
//    int size;
//
//public:
//    Stack() : top(nullptr), size(0) {}
//
//    ~Stack() {
//        while (!isEmpty()) {
//            pop();
//        }
//    }
//
//    bool isEmpty() {
//        return top == nullptr;
//    }
//
//    void push(int value) {
//        Node* newNode = new Node{ value, top };
//        top = newNode;
//        size++;
//    }
//
//    int pop() {
//        if (isEmpty()) {
//            std::cerr << "Ошибка: стек пуст!" << std::endl;
//            return -1;
//        }
//        Node* temp = top;
//        int value = top->data;
//        top = top->next;
//        delete temp;
//        size--;
//        return value;
//    }
//
//    int peek() {
//        if (isEmpty()) {
//            std::cerr << "Ошибка: стек пуст!" << std::endl;
//            return -1;
//        }
//        return top->data;
//    }
//
//    void printStack() {
//        Node* current = top;
//        std::cout << "Содержимое стека: ";
//        while (current) {
//            std::cout << current->data << " ";
//            current = current->next;
//        }
//        std::cout << std::endl;
//    }
//};
//
//int main() {
//    setlocale(LC_ALL, "Russian");
//    Stack stack;
//
//    stack.push(10);
//    stack.push(20);
//    stack.push(30);
//    stack.printStack();
//
//    std::cout << "Элемент на вершине: " << stack.peek() << std::endl;
//
//    stack.pop();
//    stack.printStack();
//
//    stack.push(40);
//    stack.printStack();
//
//    return 0;
//}







#include <iostream>

struct Node {
    int data;
    Node* next;
};

class LinkedList {
private:
    Node* head;

public:
    LinkedList() : head(nullptr) {}

    ~LinkedList() {
        while (head) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }

    void append(int value) {
        Node* newNode = new Node{ value, nullptr };
        if (!head) {
            head = newNode;
        }
        else {
            Node* temp = head;
            while (temp->next) {
                temp = temp->next;
            }
            temp->next = newNode;
        }
    }

    void printList() const {
        Node* temp = head;
        std::cout << "Список: ";
        while (temp) {
            std::cout << temp->data << " ";
            temp = temp->next;
        }
        std::cout << std::endl;
    }

    Node* clone() const {
        if (!head) return nullptr;

        Node* newHead = new Node{ head->data, nullptr };
        Node* current = head->next;
        Node* newCurrent = newHead;

        while (current) {
            newCurrent->next = new Node{ current->data, nullptr };
            current = current->next;
            newCurrent = newCurrent->next;
        }
        return newHead;
    }

    LinkedList operator+(const LinkedList& other) const {
        LinkedList result;

        Node* current = head;
        while (current) {
            result.append(current->data);
            current = current->next;
        }

        current = other.head;
        while (current) {
            result.append(current->data);
            current = current->next;
        }

        return result;
    }

    LinkedList operator*(const LinkedList& other) const {
        LinkedList result;

        Node* current1 = head;
        while (current1) {
            Node* current2 = other.head;
            while (current2) {
                if (current1->data == current2->data) {
                    result.append(current1->data);
                    break;
                }
                current2 = current2->next;
            }
            current1 = current1->next;
        }

        return result;
    }

    Node* getHead() const { return head; }
};

int main() {
    setlocale(LC_ALL, "Russian");
    LinkedList list1, list2;

    list1.append(1);
    list1.append(2);
    list1.append(3);

    list2.append(2);
    list2.append(3);
    list2.append(4);

    std::cout << "Первый список: ";
    list1.printList();

    std::cout << "Второй список: ";
    list2.printList();

    std::cout << "Клонированный первый список: ";
    Node* clonedHead = list1.clone(); 
    LinkedList clonedList;
    clonedList = LinkedList(); 
    clonedList.printList();

    std::cout << "Объединение списков (list1 + list2): ";
    LinkedList mergedList = list1 + list2;
    mergedList.printList();

    std::cout << "Общие элементы (list1 * list2): ";
    LinkedList commonList = list1 * list2;
    commonList.printList();

    return 0;
}
